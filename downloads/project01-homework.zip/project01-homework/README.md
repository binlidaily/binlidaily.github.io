# 作业 01：下一个字符实验台

这是一份可以动手修改的起始工程，不是答案。它故意使用**只看最后一个字符**的最小模型：`字符 ID → Embedding → Linear → Logits`。先看清生成闭环，再在下一项目加入上下文。

## 先运行基线

需要 Python 3.10+ 和 PyTorch。建议在独立环境安装与你电脑匹配的 PyTorch（安装命令以 [PyTorch 官网](https://pytorch.org/get-started/locally/) 为准）。

```bash
python lab.py train --data data/demo.txt --steps 300 --save runs/baseline.pt
python lab.py inspect --checkpoint runs/baseline.pt --prompt 我喜欢
python lab.py generate --checkpoint runs/baseline.pt --prompt 我 --sampler greedy --max-new 20
```

`data/demo.txt` 只是让程序立即跑通的演示语料，不能用它评价模型好坏。正式实验换成你自己有权使用的 100～300 行短句；保持训练/验证划分和字符表不变再做对照。

## 改代码的位置

| 题目 | 文件中的位置 | 你要改什么 | 运行后交什么 |
| --- | --- | --- | --- |
| Q1 编码 | `TODO Q1` | 打印输入文字、字符、ID；给未知字符加一个测试 | 5 个 encode/decode 样例和你的解释 |
| Q2 Embedding | `TODO Q2` | 打印权重形状、某字符向量训练前后差异 | 形状和真实数值；解释 ID 不等于向量 |
| Q3 训练 | `TODO Q3` | 改 `dim`、训练步数；记录训练/验证 loss | 至少两组同语料对照，不能只贴生成句子 |
| Q4 采样 | `TODO Q4` | 实现 Temperature、Top-K、Top-P 的空白函数 | 固定同一 logits，比较候选数与概率 |
| Q5 局限 | `TODO Q5` | 对比“我喜欢”与“苹果喜欢”的下一步概率 | 写出为何两者完全相同，再提出改进方向 |

推荐顺序：**Q1 → Q2 → Q3 → Q5 → Q4**。每题先在 `report.md` 写一句预测，再动代码；只改一个变量，固定随机种子，保存命令和输出。

## 验收

1. 基线能训练、保存 checkpoint、重新加载并生成；`python -m unittest discover -s tests` 通过基线测试。
2. `inspect` 能展示字符 ID、Embedding 向量、Logits 和概率，说明它们各是什么。
3. Q4 的三个函数完成后，扩展测试通过；概率有限、非负、和为 1，Top-K=1 只留下一个候选。
4. 用同一 checkpoint 证明“我喜欢”和“苹果喜欢”下一步概率相同。注意：这不是“模型理解两句话一样”，而是代码只取最后一个字符。
5. `report.md` 含预测、命令、结果、失败例和解释；不把演示语料上的输出称为大模型能力。

卡住时先看 `python lab.py --help`。不要同时改模型结构、语料和采样参数；否则你不知道是什么引起了变化。

