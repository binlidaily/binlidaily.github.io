"""作业 01 起始代码：字符级 neural bigram。用 TODO 搜索作业位置。"""

import argparse
import random
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F

SPECIAL = ["<BOS>", "<EOS>", "<UNK>"]


def prepare_lines(path):
    lines = list(dict.fromkeys(s.strip() for s in Path(path).read_text(encoding="utf-8").splitlines() if s.strip()))
    if len(lines) < 10:
        raise ValueError("至少需要 10 条非重复句子")
    random.Random(42).shuffle(lines)
    cut = max(1, len(lines) // 10)
    return lines[cut:], lines[:cut]


def make_vocab(train_lines):
    tokens = SPECIAL + sorted(set("".join(train_lines)))
    return {token: i for i, token in enumerate(tokens)}


def encode(text, vocab):
    return [vocab.get(char, vocab["<UNK>"]) for char in text]


def decode(ids, vocab):
    reverse = {i: char for char, i in vocab.items()}
    return "".join(reverse[i] for i in ids if reverse[i] not in ("<BOS>", "<EOS>"))


def make_pairs(lines, vocab):
    xs, ys = [], []
    for line in lines:
        sequence = [vocab["<BOS>"]] + encode(line, vocab) + [vocab["<EOS>"]]
        xs.extend(sequence[:-1])
        ys.extend(sequence[1:])
    return torch.tensor(xs, dtype=torch.long), torch.tensor(ys, dtype=torch.long)


class CharBigram(nn.Module):
    def __init__(self, vocab_size, dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, dim)
        self.head = nn.Linear(dim, vocab_size)

    def forward(self, ids):
        # ids: [B, T] -> vectors: [B, T, d] -> logits: [B, T, V]
        return self.head(self.embedding(ids))


def train(args):
    random.seed(42)
    torch.manual_seed(42)
    train_lines, valid_lines = prepare_lines(args.data)
    vocab = make_vocab(train_lines)
    train_x, train_y = make_pairs(train_lines, vocab)
    valid_x, valid_y = make_pairs(valid_lines, vocab)
    model = CharBigram(len(vocab), args.dim)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    before = model.embedding.weight.detach().clone()
    print(f"train/valid lines: {len(train_lines)}/{len(valid_lines)}; vocab: {len(vocab)}")
    for step in range(args.steps + 1):
        if step % max(1, args.steps // 5) == 0:
            model.eval()
            with torch.no_grad():
                train_loss = F.cross_entropy(model(train_x[:, None])[:, 0, :], train_y)
                valid_loss = F.cross_entropy(model(valid_x[:, None])[:, 0, :], valid_y)
            print(f"step={step:4d} train={train_loss.item():.4f} valid={valid_loss.item():.4f}")
            model.train()
        if step == args.steps:
            break
        optimizer.zero_grad()
        logits = model(train_x[:, None])[:, 0, :]
        loss = F.cross_entropy(logits, train_y)  # 输入是原始 logits；不要先 softmax
        loss.backward()
        optimizer.step()
    delta = (model.embedding.weight[vocab.get("我", 0)] - before[vocab.get("我", 0)]).abs().max().item()
    print(f"Embedding 向量最大变化（‘我’或替代 ID）: {delta:.6f}")
    # TODO Q2：再打印一个字符的 ID、Embedding 行向量及形状；解释这行向量为何会变化。
    # TODO Q3：固定数据、种子和其他参数，只改变 dim 或 steps；记录验证 loss 是否同步改善。
    output = Path(args.save)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state": model.state_dict(), "vocab": vocab, "dim": args.dim}, output)
    print(f"saved: {output}")


def load(path):
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    model = CharBigram(len(checkpoint["vocab"]), checkpoint["dim"])
    model.load_state_dict(checkpoint["state"])
    model.eval()
    return model, checkpoint["vocab"]


def next_logits(model, vocab, prompt):
    last = encode(prompt[-1], vocab)[0] if prompt else vocab["<BOS>"]
    with torch.no_grad():
        return model(torch.tensor([[last]]))[0, -1]


def inspect(args):
    model, vocab = load(args.checkpoint)
    last = args.prompt[-1] if args.prompt else "<BOS>"
    token_id = encode(last, vocab)[0] if args.prompt else vocab["<BOS>"]
    logits = next_logits(model, vocab, args.prompt)
    probs = F.softmax(logits, dim=-1)
    reverse = {i: token for token, i in vocab.items()}
    print("input:", args.prompt, "last character:", last, "ID:", token_id)
    print("embedding:", model.embedding.weight[token_id].detach().tolist())
    print("shapes: IDs=[1,1], Embedding=[1,1,%d], Logits=[1,1,%d]" % (model.embedding.embedding_dim, len(vocab)))
    print("top candidates:")
    for p, idx in zip(*torch.topk(probs, min(5, len(vocab)))):
        print(repr(reverse[idx.item()]), "logit=%.4f" % logits[idx].item(), "prob=%.4f" % p.item())
    # TODO Q1：把 prompt 的每个字符及其 ID 都打印出来。试一个词表外字符并解释 <UNK>。
    # TODO Q5：对同一 checkpoint 分别 inspect “我喜欢”与“苹果喜欢”；为何分布相同？


def sample_from_logits(logits, sampler="greedy", temperature=1.0, top_k=5, top_p=0.9):
    if sampler == "greedy":
        return torch.argmax(logits).item()
    if temperature <= 0:
        raise ValueError("temperature 必须大于 0")
    scaled = logits / temperature
    if sampler == "temperature":
        probs = F.softmax(scaled, dim=-1)
    elif sampler == "topk":
        # TODO Q4a：只保留得分最高的 k 个候选，其余置为 -inf，再 softmax。
        raise NotImplementedError("完成 TODO Q4a")
    elif sampler == "topp":
        # TODO Q4b：按概率降序累加，保留刚好达到 p 的最小前缀；至少留 1 个。
        raise NotImplementedError("完成 TODO Q4b")
    else:
        raise ValueError(f"unknown sampler: {sampler}")
    # TODO Q4c：打印过滤后非零候选的数量、概率和；同一 logits 改参数比较。
    return torch.multinomial(probs, 1).item()


def generate(args):
    torch.manual_seed(args.seed)
    model, vocab = load(args.checkpoint)
    reverse = {i: token for token, i in vocab.items()}
    result = args.prompt
    for _ in range(args.max_new):
        logits = next_logits(model, vocab, result)
        token_id = sample_from_logits(logits, args.sampler, args.temperature, args.top_k, args.top_p)
        token = reverse[token_id]
        if token == "<EOS>":
            break
        result += token if token not in SPECIAL else "?"
    print(result)


def main():
    parser = argparse.ArgumentParser(description="作业 01：下一个字符实验台")
    sub = parser.add_subparsers(dest="command", required=True)
    tr = sub.add_parser("train")
    tr.add_argument("--data", default="data/demo.txt")
    tr.add_argument("--steps", type=int, default=300)
    tr.add_argument("--dim", type=int, default=16)
    tr.add_argument("--lr", type=float, default=0.03)
    tr.add_argument("--save", default="runs/baseline.pt")
    ins = sub.add_parser("inspect")
    ins.add_argument("--checkpoint", default="runs/baseline.pt")
    ins.add_argument("--prompt", default="我喜欢")
    gen = sub.add_parser("generate")
    gen.add_argument("--checkpoint", default="runs/baseline.pt")
    gen.add_argument("--prompt", default="我")
    gen.add_argument("--sampler", choices=["greedy", "temperature", "topk", "topp"], default="greedy")
    gen.add_argument("--temperature", type=float, default=1.0)
    gen.add_argument("--top-k", type=int, default=5)
    gen.add_argument("--top-p", type=float, default=0.9)
    gen.add_argument("--max-new", type=int, default=20)
    gen.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.command == "train":
        train(args)
    elif args.command == "inspect":
        inspect(args)
    else:
        generate(args)


if __name__ == "__main__":
    main()
