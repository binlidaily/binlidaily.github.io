import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    import torch
    from lab import CharBigram, decode, encode, make_pairs, make_vocab, next_logits, sample_from_logits
except ImportError:
    torch = None


@unittest.skipIf(torch is None, "先安装 PyTorch")
class BaselineTests(unittest.TestCase):
    def setUp(self):
        self.vocab = make_vocab(["我喜欢苹果。", "苹果喜欢我。"])

    def test_round_trip(self):
        for text in ["我", "苹果", "我喜欢苹果。", "喜欢我", ""]:
            self.assertEqual(decode(encode(text, self.vocab), self.vocab), text)

    def test_shifted_targets(self):
        x, y = make_pairs(["我喜欢"], self.vocab)
        self.assertEqual(x[0].item(), self.vocab["<BOS>"])
        self.assertEqual(y[0].item(), self.vocab["我"])
        self.assertEqual(y[-1].item(), self.vocab["<EOS>"])

    def test_shapes_and_context_limit(self):
        model = CharBigram(len(self.vocab), 8)
        ids = torch.tensor([[self.vocab["我"], self.vocab["喜"]]])
        self.assertEqual(tuple(model.embedding(ids).shape), (1, 2, 8))
        self.assertEqual(tuple(model(ids).shape), (1, 2, len(self.vocab)))
        torch.testing.assert_close(next_logits(model, self.vocab, "我喜欢"), next_logits(model, self.vocab, "苹果喜欢"))

    def test_greedy_and_temperature(self):
        logits = torch.tensor([1.0, 3.0, 0.0])
        self.assertEqual(sample_from_logits(logits, "greedy"), 1)
        self.assertIn(sample_from_logits(logits, "temperature", temperature=0.7), range(3))
        with self.assertRaises(ValueError):
            sample_from_logits(logits, "temperature", temperature=0)


@unittest.skipIf(torch is None, "先安装 PyTorch")
class AfterTodoTests(unittest.TestCase):
    def test_topk_after_q4a(self):
        logits = torch.tensor([1.0, 4.0, 0.0])
        try:
            result = sample_from_logits(logits, "topk", top_k=1)
        except NotImplementedError:
            self.skipTest("等待 TODO Q4a")
        self.assertEqual(result, 1)

    def test_topp_after_q4b(self):
        logits = torch.tensor([1.0, 4.0, 0.0])
        try:
            result = sample_from_logits(logits, "topp", top_p=0.1)
        except NotImplementedError:
            self.skipTest("等待 TODO Q4b")
        self.assertEqual(result, 1)


if __name__ == "__main__":
    unittest.main()
